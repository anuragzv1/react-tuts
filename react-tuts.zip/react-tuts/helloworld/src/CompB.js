import react from 'react';


class CompB extends react.Component{

   
    render(){
        return (
            <>
                Count 10 reached!
            </>
        )
    }
}

export default CompB;